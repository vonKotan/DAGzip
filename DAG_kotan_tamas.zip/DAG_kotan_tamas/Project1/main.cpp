
#include <iostream>
#include "point.h"
#include <string>


//A gr�flist�ban ellen�rzi a duplik�ci�t
std::vector<Point*> duplicationcheck(std::string startpointname, std::vector<Point*> graphpoints) {
	bool startduplicate = false;
	for (int i = 0; i < graphpoints.size(); i++) {
		if (graphpoints[i]->getName() == startpointname) {
			startduplicate = true;
		}
	}
	if (!startduplicate) {
		graphpoints.push_back(new Point(startpointname));
	}
	return graphpoints;
}

//A gr�fpontok k�z�tt "beh�zza az �let"
void connection(std::string startpointname, std::string endpointname, std::vector<Point*> graphpoints) {
	int s = 0;
	int e = 0;
	for (int i = 0; i < graphpoints.size(); i++) {
		if (graphpoints[i]->getName() == startpointname) {
			s = i;
		}
		if (graphpoints[i]->getName() == endpointname) {
			e = i;
		}
	}
	graphpoints[s]->Connect(graphpoints[e]);
}

//Ki�rat�st �s az �lt�rl�st v�gz� algoritmus, DAG ellen�rz�s (a matematikai oldala a dokument�ci�bal elmagyar�zva)
void write(std::vector<Point*> graphpoints) {
	int layer = 1;
	int deletecount = 0;

	while (deletecount < graphpoints.size()) {
		int deletcountchecker =deletecount;

		printf("%d  ", layer);
		std::vector<int> deletepoints;

		for (int i = 0; i < graphpoints.size(); i++) {
			if (graphpoints[i]->getPointsAt().size() == 0 && graphpoints[i]->getConnected()) {
				std::cout << graphpoints[i]->getName() << " ";
				deletepoints.push_back(i);
			}
		}

		for (int i = 0; i < deletepoints.size(); i++) {
			graphpoints[deletepoints[i]]->Unconnect();
			deletecount++;
		}

		printf("\n");
		layer++;

		if (deletecount == deletcountchecker) {
			std::cout << "itt a grafban iranyitott kor van, nem DAG";
			break;
		}
	}
}

//beolvas�si hib�k
//�nmag�ba mutat� �l ellen�rz�se
 bool onel(std::string A, std::string B) {
	if (A == B) {
		std::cout << "Hibas bemenet, nem engedelyezett az iranyitott kor\n";
		return true;
	}
	return false;
}
 
 //hianyzo nyil
 bool noarrow(std::string line) {
	 std::size_t arrowPos = line.find("->");
	 if(arrowPos == std::string::npos){
		 return true;
	 }
	 return false;
 }

 //a beolvasas vegfeltetelet kezeli
 bool isend(std::string line, std::vector<Point*> graphpoints, std::vector<Point*> onepoint) {
	 if (onepoint.size() == 1 && line == "end" && graphpoints.size() == 0) {
		 std::cout << "Reading finished.\n";
		 std::cout << "1" << " " << onepoint[0]->getName() << "\n ez egy egypontu graf, vagy hibas volt a bemenet";
		 return true;
	 }
	 if (line == "end") {
		 return true;
	 }
	 return false;
 }

//MAIN
int main() {
	//V�LTOZ�K
	std::vector<Point*> graphpoints; //gr�fpontok vektora
	std::string line; //soronk�nt olvasunk be, egy sorban egy �lniy inform�ci� van, ezt ebbe a stringbe mentj�k
	std::vector<Point*> onepoint; // az egypontu graf kulon kezelesere

	 //BEOLVAS�S
	std::cout << "Adja meg a graf eleit 'A->B' formatumban, befejezeshez irja az 'end' szot\n";
	while (std::getline(std::cin, line)) {
		//befejezofeltetel es egypontu graf kezelese
		if (isend(line, graphpoints, onepoint)) {
			break;
		}
		/*
		if (onepoint.size() == 1 && line == "end" && graphpoints.size()==0) {
			std::cout << "Reading finished.\n";
			std::cout << "1" << " " << onepoint[0]->getName() << "\n ez egy egypontu graf, vagy hibas volt a bemenet";
			break;
		}
		if (line == "end") {
			break;
		}
		*/

		//nyil megkeresese a sorban es hianyzo nyil kezelese
		std::size_t arrowPos = line.find("->");
		if (noarrow(line) && graphpoints.size()==0 && onepoint.size()==0) {
			onepoint.push_back(new Point(line));
			continue;
		}
		else if (noarrow(line)) {
			std::cout << "Hibas bemenet, nincs nyil '->'." << std::endl;
			continue;
		}

		// a kezd� �s a v�gpont nev�nek lev�laszt�sa
		std::string startpointname = line.substr(0, arrowPos);
		std::string endpointname = line.substr(arrowPos + 2);

		//egy�b hib�k kezel�se
		if (!onel(startpointname, endpointname)) {

			//gr�fpontok felv�tele egy vektorba, duplik�ci� ellen�rz�s�vel
			graphpoints = duplicationcheck(startpointname, graphpoints);
			graphpoints = duplicationcheck(endpointname, graphpoints);

			//l�trehozza a kapcsolatot a gr�fpontok k�z�tt
			connection(startpointname, endpointname, graphpoints);
		}

	}
	//beolvasas befejezese, bemenet vegso kiertekelese
	if (graphpoints.size() > 1) {
		std::cout << "Beolvasas vege.\n";
	}
	else if (!onepoint.size() == 1) {
		std::cout << "hibas bemenet, nem talaltam grafot";
	}
	//dag ellenorzes, tobb darabbol allo graf

	//ALGORITMUS ES KIIRAS
	write(graphpoints);
	return 0;
}




