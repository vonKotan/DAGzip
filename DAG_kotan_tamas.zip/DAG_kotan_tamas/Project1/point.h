#ifndef POINT_H
#define POINT_H

#include <vector>
#include <string>

class Point {
private:
    std::string name;
    bool connected=true;
    std::vector<std::string> pointsAt;
    std::vector<Point*> pointsFrom;

public:
    // Constructors
    Point(std::string name);
    Point(std::string name, Point* pointsFrom);

    // Setters
    void setName(std::string newName);
    void addPointAt(std::vector<std::string> point);
    void addPointFrom(Point* point);

    // Getters
    std::string getName() const;
    bool getConnected() const;
    std::vector<std::string> getPointsAt() const;
    std::vector<Point*> getPointsFrom() const;

    // Connects the current point to the given endpoint
    void Connect(Point* endpoint);

    // Removes the connections between the current point and other points
    void Unconnect();
};

#endif
