#include "point.h"
#include <iostream>

// Constructors
Point::Point(std::string name) : name(name) {}

Point::Point(std::string name, Point* pointsFrom) : name(name) {
    addPointFrom(pointsFrom);
}

// Setters
void Point::setName(std::string newName) {
    name = newName;
}

void Point::addPointFrom(Point* point) {
    pointsFrom.push_back(point);
}

// Getters
std::string Point::getName() const {
    return name;
}

bool Point::getConnected() const
{
    return connected;
}

std::vector<std::string> Point::getPointsAt() const {
    return pointsAt;
}

std::vector<Point*> Point::getPointsFrom() const {
    return pointsFrom;
}


void Point::Connect(Point* endpoint) {
    pointsFrom.push_back(endpoint);
    endpoint->pointsAt.push_back(name);
    //std::cout << name;
    //std::cout << endpoint->getName();
}

void Point::Unconnect() {
    for (int i = 0; i < pointsFrom.size(); i++) {
        for (int j = 0; j < pointsFrom[i]->pointsAt.size(); j++) {
            if (pointsFrom[i]->pointsAt[j] == name) {
                pointsFrom[i]->pointsAt.erase(pointsFrom[i]->pointsAt.begin() + j);
            }
        }
    }
    connected = false;
}
